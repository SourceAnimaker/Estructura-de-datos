/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.eva_2_9_arbol;

/**
 *
 * @author W11
 */
public class EVA_2_9_Arbol {

    public static void main(String[] args) {
        ArbolBinario arbol = new ArbolBinario();
        arbol.agregarNodo(50);
        arbol.agregarNodo(30);
        arbol.agregarNodo(60);
        arbol.agregarNodo(35);
        arbol.agregarNodo(27);
        arbol.agregarNodo(68);
        arbol.agregarNodo(59);
        arbol.agregarNodo(58);
    }
}
