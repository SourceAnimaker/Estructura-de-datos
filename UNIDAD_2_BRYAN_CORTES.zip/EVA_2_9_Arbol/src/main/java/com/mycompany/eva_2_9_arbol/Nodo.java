/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.eva_2_9_arbol;

public class Node {
    private int value;
    private Node der;
    private Node izq;

    public Node() {
        der = null;
        izq = null;
    }

    public Node(int value) {
        this.value = value;
        der = null;
        izq = null;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public Node getder() {
        return der;
    }

    public void setder(Node next) {
        this.der = next;
    }
    
    public Node getizq() {
        return izq;
    }

    public void setizq(Node next) {
        this.izq = next;
    }

    String getValor() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}